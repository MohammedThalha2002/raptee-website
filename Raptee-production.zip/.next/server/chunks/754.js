"use strict";
exports.id = 754;
exports.ids = [754];
exports.modules = {

/***/ 6124:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);




function Footer() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "bg-black w-screen flex justify-around flex-wrap",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "py-10 px-2 w-56",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "title",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: " font-oswald font-light text-2xl tracking-wide sm:text-xl",
                                children: "HEAD OFFICE"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "underline w-10 h-0.5 rounded-xl my-2 mr-32 bg-highlight"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-6 tracking-wide sm:text-sm",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                children: "NO 9, Ganapathy Nagar"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                children: "1st St, Navarathna Garden,"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                children: "Ekkatuthangal, Chennai,"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                children: "Tamil Nadu 600032"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "py-10 px-2 w-52",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "title",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: " font-oswald font-light text-2xl tracking-wide sm:text-xl",
                                children: "CONTACT"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "underline w-10 h-0.5 rounded-xl my-2 mr-32 bg-highlight"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-6 tracking-wide sm:text-sm",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                children: "Ph. No: +91 8925061646"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                children: "contact@rapteemotors.com"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex justify-between mt-4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: "https://www.linkedin.com/company/rapteeenergy/?viewAsMember=true",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/images/linkedin.png",
                                    width: 25,
                                    height: 25,
                                    className: "cursor-pointer"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: "https://www.instagram.com/rapteeenergy/",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/images/insta.png",
                                    width: 25,
                                    height: 25,
                                    className: "cursor-pointer"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: "https://twitter.com/RapteeEnergy",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/images/twitter.png",
                                    width: 25,
                                    height: 25,
                                    className: "cursor-pointer"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: "https://www.facebook.com/rapteemotors",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: "/images/facebook.png",
                                    width: 25,
                                    height: 25,
                                    className: "cursor-pointer"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "py-10 px-2 w-52",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "title",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: " font-oswald font-light text-2xl tracking-wide sm:text-xl",
                                children: "SUPPORT US"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "underline w-10 h-0.5 rounded-xl my-2 mr-32 bg-highlight"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-6 tracking-wide sm:text-sm",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                children: "We are on continuous "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                children: "lookout for investors who"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                children: "share our passion"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                children: "towards motorcycles and"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                children: "help us achieve our goal"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                children: "of sustainable mobility"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "py-10 px-2 w-52",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "tracking-wide sm:text-sm",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "my-2",
                                children: "Privacy Policy"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "my-2",
                                children: "Refund Policy"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "my-2",
                                children: "Terms of Services"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "underline w-10 h-0.5 rounded-xl my-2 mr-32 bg-highlight"
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 3511:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_NavBar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react-icons/lib"
var lib_ = __webpack_require__(2283);
// EXTERNAL MODULE: external "react-icons/io"
var io_ = __webpack_require__(4751);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "gsap/dist/gsap.js"
var gsap_js_ = __webpack_require__(8716);
;// CONCATENATED MODULE: ./components/NavLinks.js






function NavLinks(props) {
    function cloaseNavLinks() {
        console.log("Closed the NAVLINK");
        gsap_js_.gsap.fromTo(props.reference.current, {
            opacity: 1,
            x: -384
        }, {
            opacity: 0,
            x: 0,
            duration: 0.5,
            ease: "ease-in"
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("nav", {
        className: "pt-4 px-8 backdrop-blur-lg bg-gray-400/50 z-50 h-100vh w-96 shadow-md top-0 -right-96 fixed sm:w-2/3",
        ref: props.reference,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col items-end",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                            children: "Close"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(lib_.IconContext.Provider, {
                            value: {
                                color: "#E0B317",
                                size: "2rem"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(io_.IoMdClose, {
                                onClick: cloaseNavLinks,
                                className: "cursor-pointer"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/home",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl sm:text-xl my-8 cursor-pointer ease-in duration-100 hover:text-4xl sm:hover:text-2xl",
                        children: "Home"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/techstory",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl sm:text-xl my-8 cursor-pointer ease-in duration-100 hover:text-4xl sm:hover:text-2xl",
                        children: "Tech Story"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/home",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl sm:text-xl my-8 cursor-pointer ease-in duration-100 hover:text-4xl sm:hover:text-2xl",
                        children: "OEM Solutions"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/culture",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl sm:text-xl my-8 cursor-pointer ease-in duration-100 hover:text-4xl sm:hover:text-2xl",
                        children: "Culture"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/home",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl sm:text-xl my-8 cursor-pointer ease-in duration-100 hover:text-4xl sm:hover:text-2xl",
                        children: "Contact"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "https://apply.workable.com/raptee-energy/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl sm:text-xl my-8 cursor-pointer ease-in duration-100 hover:text-4xl sm:hover:text-2xl",
                        children: "Career"
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const components_NavLinks = (NavLinks);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/NavBar.jsx









function NavBar(props) {
    const btnRef = (0,external_react_.useRef)();
    function openNavLinks() {
        console.log("Clicked");
        gsap_js_.gsap.fromTo(btnRef.current, {
            opacity: 0,
            x: 0
        }, {
            opacity: 1,
            x: -384,
            duration: 0.5,
            ease: "ease-in"
        });
    }
    function LogoComponent() {
        if (props.mobile) {
            // MOBILE
            return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/home",
                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                    width: "98",
                    height: "10",
                    className: "cursor-pointer",
                    viewBox: "0 0 98 10",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M13.746 4.23857C13.746 4.79404 13.5991 5.29525 13.3054 5.74218C13.0117 6.18273 12.6222 6.51154 12.137 6.72862L12.1753 6.80524L13.6981 10.004C13.7045 10.0295 13.7013 10.0551 13.6885 10.0806C13.6757 10.1062 13.6534 10.1189 13.6215 10.1189H11.6773C11.6454 10.1189 11.6198 10.103 11.6007 10.071L10.1258 6.97763H1.98525V10.0423C1.98525 10.0615 1.97567 10.0806 1.95652 10.0998C1.94375 10.1125 1.92459 10.1189 1.89906 10.1189H0.146441C0.127287 10.1189 0.108133 10.1125 0.0889785 10.0998C0.076209 10.0806 0.0698242 10.0615 0.0698242 10.0423V0.627993C0.0698242 0.602454 0.076209 0.5833 0.0889785 0.57053C0.108133 0.551376 0.127287 0.541799 0.146441 0.541799H11.0165C11.7699 0.541799 12.4115 0.809958 12.9415 1.34628C13.4778 1.87621 13.746 2.52107 13.746 3.28086V4.23857ZM1.98525 5.33036H11.0165C11.2399 5.33036 11.4315 5.25055 11.5911 5.09093C11.7507 4.93132 11.8305 4.73658 11.8305 4.50673V3.00312C11.8305 2.77965 11.7507 2.58811 11.5911 2.42849C11.4315 2.26887 11.2399 2.18906 11.0165 2.18906H1.98525V5.33036ZM25.3726 1.26966C25.8834 0.784419 26.4644 0.541799 27.1156 0.541799H30.9369C30.9624 0.541799 30.9816 0.551376 30.9944 0.57053C31.0135 0.5833 31.0231 0.602454 31.0231 0.627993V10.0423C31.0231 10.0615 31.0135 10.0806 30.9944 10.0998C30.9816 10.1125 30.9624 10.1189 30.9369 10.1189H29.1843C29.1651 10.1189 29.146 10.1125 29.1268 10.0998C29.1141 10.0806 29.1077 10.0615 29.1077 10.0423V2.18906H27.5083C27.2912 2.18906 27.0997 2.26887 26.9337 2.42849L19.2145 10.0998C19.1953 10.1125 19.1762 10.1189 19.157 10.1189H16.7149C16.6766 10.1189 16.651 10.103 16.6383 10.071C16.6255 10.0391 16.6319 10.0104 16.6574 9.98485L25.3726 1.26966ZM33.8962 0.618416C33.8962 0.599262 33.9026 0.5833 33.9154 0.57053C33.9345 0.551376 33.9537 0.541799 33.9729 0.541799H44.8429C45.5963 0.541799 46.238 0.809958 46.7679 1.34628C47.3042 1.87621 47.5724 2.51788 47.5724 3.27128V4.22899C47.5724 4.98878 47.3042 5.63683 46.7679 6.17315C46.238 6.70308 45.5963 6.96805 44.8429 6.96805H35.8117V10.0327C35.8117 10.0583 35.8021 10.0806 35.7829 10.0998C35.7702 10.1125 35.751 10.1189 35.7255 10.1189H33.9729C33.9537 10.1189 33.9345 10.1125 33.9154 10.0998C33.9026 10.0806 33.8962 10.0583 33.8962 10.0327V0.618416ZM44.8429 5.33036C45.0664 5.33036 45.2579 5.25055 45.4175 5.09093C45.5771 4.92493 45.657 4.7302 45.657 4.50673V3.00312C45.657 2.77327 45.5771 2.57853 45.4175 2.41892C45.2579 2.2593 45.0664 2.17949 44.8429 2.17949H35.8117V5.33036H44.8429ZM50.4455 0.627993C50.4455 0.602454 50.4519 0.5833 50.4647 0.57053C50.4838 0.551376 50.503 0.541799 50.5221 0.541799H64.045C64.0642 0.541799 64.0802 0.551376 64.0929 0.57053C64.1121 0.5833 64.1217 0.602454 64.1217 0.627993V2.10287C64.1217 2.12203 64.1121 2.14118 64.0929 2.16033C64.0802 2.1731 64.0642 2.17949 64.045 2.17949H58.2413V10.0327C58.2413 10.0583 58.2317 10.0806 58.2126 10.0998C58.1998 10.1125 58.1838 10.1189 58.1647 10.1189H56.4121C56.3865 10.1189 56.3642 10.1125 56.345 10.0998C56.3323 10.0806 56.3259 10.0583 56.3259 10.0327V2.17949H50.5221C50.503 2.17949 50.4838 2.1731 50.4647 2.16033C50.4519 2.14118 50.4455 2.12203 50.4455 2.10287V0.627993ZM68.9102 3.00312C68.9102 2.77965 68.99 2.58811 69.1497 2.42849C69.3093 2.26249 69.504 2.17949 69.7339 2.17949H80.5943C80.6199 2.17949 80.639 2.1731 80.6518 2.16033C80.6709 2.14118 80.6805 2.12203 80.6805 2.10287V0.627993C80.6805 0.602454 80.6709 0.5833 80.6518 0.57053C80.639 0.551376 80.6199 0.541799 80.5943 0.541799H69.7339C68.9741 0.541799 68.326 0.809958 67.7897 1.34628C67.2598 1.87621 66.9948 2.52107 66.9948 3.28086V7.37987C66.9948 8.13965 67.2598 8.78771 67.7897 9.32403C68.326 9.85396 68.9741 10.1189 69.7339 10.1189H80.5943C80.6199 10.1189 80.639 10.1125 80.6518 10.0998C80.6709 10.0806 80.6805 10.0583 80.6805 10.0327V8.55786C80.6805 8.5387 80.6709 8.52274 80.6518 8.50997C80.639 8.49082 80.6199 8.48124 80.5943 8.48124H69.7339C69.504 8.48124 69.3093 8.40143 69.1497 8.24181C68.99 8.07581 68.9102 7.88107 68.9102 7.65761V6.154H79.2248C79.2503 6.154 79.2695 6.14761 79.2823 6.13484C79.3014 6.11569 79.311 6.09334 79.311 6.0678V4.59292C79.311 4.56739 79.3014 4.54823 79.2823 4.53546C79.2695 4.51631 79.2503 4.50673 79.2248 4.50673H68.9102V3.00312ZM85.4787 3.00312C85.4787 2.77965 85.5585 2.58811 85.7181 2.42849C85.8777 2.26249 86.0724 2.17949 86.3023 2.17949H97.1628C97.1883 2.17949 97.2074 2.1731 97.2202 2.16033C97.2394 2.14118 97.2489 2.12203 97.2489 2.10287V0.627993C97.2489 0.602454 97.2394 0.5833 97.2202 0.57053C97.2074 0.551376 97.1883 0.541799 97.1628 0.541799H86.3023C85.5425 0.541799 84.8945 0.809958 84.3581 1.34628C83.8282 1.87621 83.5632 2.52107 83.5632 3.28086V7.37987C83.5632 8.13965 83.8282 8.78771 84.3581 9.32403C84.8945 9.85396 85.5425 10.1189 86.3023 10.1189H97.1628C97.1883 10.1189 97.2074 10.1125 97.2202 10.0998C97.2394 10.0806 97.2489 10.0583 97.2489 10.0327V8.55786C97.2489 8.5387 97.2394 8.52274 97.2202 8.50997C97.2074 8.49082 97.1883 8.48124 97.1628 8.48124H86.3023C86.0724 8.48124 85.8777 8.40143 85.7181 8.24181C85.5585 8.07581 85.4787 7.88107 85.4787 7.65761V6.154H95.7932C95.8188 6.154 95.8379 6.14761 95.8507 6.13484C95.8698 6.11569 95.8794 6.09334 95.8794 6.0678V4.59292C95.8794 4.56739 95.8698 4.54823 95.8507 4.53546C95.8379 4.51631 95.8188 4.50673 95.7932 4.50673H85.4787V3.00312Z",
                        fill: "white"
                    })
                })
            });
        } else {
            // DESKTOP
            return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/home",
                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                    width: "175",
                    height: "18",
                    className: "cursor-pointer",
                    viewBox: "0 0 175 18",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M24.6794 6.91688C24.6794 7.91643 24.4152 8.81832 23.8867 9.62256C23.3582 10.4153 22.6574 11.007 21.7842 11.3976L21.8531 11.5355L24.5933 17.2915C24.6048 17.3375 24.599 17.3834 24.576 17.4294C24.5531 17.4753 24.5128 17.4983 24.4554 17.4983H20.957C20.8995 17.4983 20.8536 17.4696 20.8191 17.4122L18.1651 11.8457H3.51655V17.3605C3.51655 17.3949 3.49931 17.4294 3.46485 17.4639C3.44187 17.4868 3.4074 17.4983 3.36145 17.4983H0.207693C0.173226 17.4983 0.138759 17.4868 0.104291 17.4639C0.0813133 17.4294 0.0698242 17.3949 0.0698242 17.3605V0.419805C0.0698242 0.373848 0.0813133 0.339381 0.104291 0.316403C0.138759 0.281936 0.173226 0.264702 0.207693 0.264702H19.7679C21.1236 0.264702 22.2782 0.747243 23.2318 1.71233C24.1969 2.66592 24.6794 3.82632 24.6794 5.19352V6.91688ZM3.51655 8.88151H19.7679C20.17 8.88151 20.5146 8.7379 20.8019 8.45067C21.0891 8.16344 21.2327 7.81303 21.2327 7.39942V4.69374C21.2327 4.29162 21.0891 3.94695 20.8019 3.65973C20.5146 3.3725 20.17 3.22888 19.7679 3.22888H3.51655V8.88151ZM45.601 1.57446C46.5202 0.701287 47.5657 0.264702 48.7376 0.264702H55.6138C55.6597 0.264702 55.6942 0.281936 55.7172 0.316403C55.7516 0.339381 55.7689 0.373848 55.7689 0.419805V17.3605C55.7689 17.3949 55.7516 17.4294 55.7172 17.4639C55.6942 17.4868 55.6597 17.4983 55.6138 17.4983H52.46C52.4256 17.4983 52.3911 17.4868 52.3566 17.4639C52.3336 17.4294 52.3222 17.3949 52.3222 17.3605V3.22888H49.4441C49.0535 3.22888 48.7088 3.3725 48.4101 3.65973L34.5198 17.4639C34.4854 17.4868 34.4509 17.4983 34.4164 17.4983H30.0219C29.9529 17.4983 29.907 17.4696 29.884 17.4122C29.861 17.3547 29.8725 17.303 29.9185 17.2571L45.601 1.57446ZM60.939 0.402571C60.939 0.368104 60.9505 0.339381 60.9734 0.316403C61.0079 0.281936 61.0424 0.264702 61.0768 0.264702H80.637C81.9927 0.264702 83.1474 0.747243 84.1009 1.71233C85.066 2.66592 85.5486 3.82057 85.5486 5.17628V6.89965C85.5486 8.26685 85.066 9.43299 84.1009 10.3981C83.1474 11.3517 81.9927 11.8285 80.637 11.8285H64.3857V17.3432C64.3857 17.3892 64.3685 17.4294 64.334 17.4639C64.311 17.4868 64.2765 17.4983 64.2306 17.4983H61.0768C61.0424 17.4983 61.0079 17.4868 60.9734 17.4639C60.9505 17.4294 60.939 17.3892 60.939 17.3432V0.402571ZM80.637 8.88151C81.0391 8.88151 81.3838 8.7379 81.671 8.45067C81.9582 8.15196 82.1018 7.80154 82.1018 7.39942V4.69374C82.1018 4.28014 81.9582 3.92972 81.671 3.64249C81.3838 3.35526 81.0391 3.21165 80.637 3.21165H64.3857V8.88151H80.637ZM90.7187 0.419805C90.7187 0.373848 90.7301 0.339381 90.7531 0.316403C90.7876 0.281936 90.8221 0.264702 90.8565 0.264702H115.19C115.225 0.264702 115.254 0.281936 115.277 0.316403C115.311 0.339381 115.328 0.373848 115.328 0.419805V3.07378C115.328 3.10825 115.311 3.14272 115.277 3.17718C115.254 3.20016 115.225 3.21165 115.19 3.21165H104.747V17.3432C104.747 17.3892 104.73 17.4294 104.695 17.4639C104.672 17.4868 104.643 17.4983 104.609 17.4983H101.455C101.409 17.4983 101.369 17.4868 101.335 17.4639C101.312 17.4294 101.3 17.3892 101.3 17.3432V3.21165H90.8565C90.8221 3.21165 90.7876 3.20016 90.7531 3.17718C90.7301 3.14272 90.7187 3.10825 90.7187 3.07378V0.419805ZM123.945 4.69374C123.945 4.29162 124.089 3.94695 124.376 3.65973C124.663 3.36101 125.014 3.21165 125.427 3.21165H144.97C145.016 3.21165 145.051 3.20016 145.073 3.17718C145.108 3.14272 145.125 3.10825 145.125 3.07378V0.419805C145.125 0.373848 145.108 0.339381 145.073 0.316403C145.051 0.281936 145.016 0.264702 144.97 0.264702H125.427C124.06 0.264702 122.894 0.747243 121.929 1.71233C120.975 2.66592 120.498 3.82632 120.498 5.19352V12.5695C120.498 13.9367 120.975 15.1028 121.929 16.0679C122.894 17.0215 124.06 17.4983 125.427 17.4983H144.97C145.016 17.4983 145.051 17.4868 145.073 17.4639C145.108 17.4294 145.125 17.3892 145.125 17.3432V14.6892C145.125 14.6548 145.108 14.6261 145.073 14.6031C145.051 14.5686 145.016 14.5514 144.97 14.5514H125.427C125.014 14.5514 124.663 14.4078 124.376 14.1205C124.089 13.8218 123.945 13.4714 123.945 13.0693V10.3636H142.506C142.552 10.3636 142.586 10.3521 142.609 10.3291C142.644 10.2947 142.661 10.2545 142.661 10.2085V7.55452C142.661 7.50857 142.644 7.4741 142.609 7.45112C142.586 7.41665 142.552 7.39942 142.506 7.39942H123.945V4.69374ZM153.759 4.69374C153.759 4.29162 153.903 3.94695 154.19 3.65973C154.477 3.36101 154.828 3.21165 155.241 3.21165H174.784C174.83 3.21165 174.865 3.20016 174.888 3.17718C174.922 3.14272 174.939 3.10825 174.939 3.07378V0.419805C174.939 0.373848 174.922 0.339381 174.888 0.316403C174.865 0.281936 174.83 0.264702 174.784 0.264702H155.241C153.874 0.264702 152.708 0.747243 151.743 1.71233C150.789 2.66592 150.313 3.82632 150.313 5.19352V12.5695C150.313 13.9367 150.789 15.1028 151.743 16.0679C152.708 17.0215 153.874 17.4983 155.241 17.4983H174.784C174.83 17.4983 174.865 17.4868 174.888 17.4639C174.922 17.4294 174.939 17.3892 174.939 17.3432V14.6892C174.939 14.6548 174.922 14.6261 174.888 14.6031C174.865 14.5686 174.83 14.5514 174.784 14.5514H155.241C154.828 14.5514 154.477 14.4078 154.19 14.1205C153.903 13.8218 153.759 13.4714 153.759 13.0693V10.3636H172.32C172.366 10.3636 172.4 10.3521 172.423 10.3291C172.458 10.2947 172.475 10.2545 172.475 10.2085V7.55452C172.475 7.50857 172.458 7.4741 172.423 7.45112C172.4 7.41665 172.366 7.39942 172.32 7.39942H153.759V4.69374Z",
                        fill: "white"
                    })
                })
            });
        }
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                className: "pt-4 px-8 backdrop-blur-sm bg-black/30 z-50 h-20vh w-full shadow-md top-0 fixed sm:pt-1 sm:px-4",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex justify-between items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(LogoComponent, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(lib_.IconContext.Provider, {
                            value: {
                                color: "white",
                                size: "2rem"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(io_.IoMdMenu, {
                                onClick: openNavLinks,
                                className: "cursor-pointer"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_NavLinks, {
                reference: btnRef
            })
        ]
    });
}
/* harmony default export */ const components_NavBar = (NavBar);


/***/ })

};
;