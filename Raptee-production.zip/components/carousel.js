// https://i.postimg.cc/prSdNtjx/1.jpg
// https://i.postimg.cc/KjTYyHDM/10.jpg
// https://i.postimg.cc/52g21vLn/11.jpg
// https://i.postimg.cc/ZYvn3Wz5/12.jpg
// https://i.postimg.cc/8CnkfSyv/13.jpg
// https://i.postimg.cc/FsjKWwRt/14.jpg
// https://i.postimg.cc/RFkMGTxV/15.jpg
// https://i.postimg.cc/hjzD95w5/16.jpg
// https://i.postimg.cc/6qCBPGBV/17.jpg
// https://i.postimg.cc/4NZGdyJM/18.jpg
// https://i.postimg.cc/RhxBwVwW/19.jpg
// https://i.postimg.cc/fbMDrbPm/2.jpg
// https://i.postimg.cc/G3vrdG1G/20.jpg
// https://i.postimg.cc/9Qdcb9Lc/3.jpg
// https://i.postimg.cc/vDRdL891/4.jpg
// https://i.postimg.cc/c4YKqrFb/5.jpg
// https://i.postimg.cc/7LXw8kvc/6.jpg
// https://i.postimg.cc/90wh7w45/7.jpg
// https://i.postimg.cc/ZRMmnx5x/8.jpg
// https://i.postimg.cc/yddB7bsN/9.jpg

export const caurosel = [
    {
        id: 1,
        img: "https://i.postimg.cc/7LXw8kvc/6.jpg"
    },
    {
        id: 2,
        img: "https://i.postimg.cc/fbMDrbPm/2.jpg"
    },
    {
        id: 3,
        img: "https://i.postimg.cc/9Qdcb9Lc/3.jpg"
    },
    {
        id: 4,
        img: "https://i.postimg.cc/vDRdL891/4.jpg"
    },
    {
        id: 5,
        img: "https://i.postimg.cc/c4YKqrFb/5.jpg"
    },
    {
        id: 6,
        img: "https://i.postimg.cc/prSdNtjx/1.jpg"
    },
    {
        id: 7,
        img: "https://i.postimg.cc/90wh7w45/7.jpg"
    },
    {
        id: 8,
        img: "https://i.postimg.cc/ZRMmnx5x/8.jpg"
    },
    {
        id: 9,
        img: "https://i.postimg.cc/yddB7bsN/9.jpg"
    },
    {
        id: 10,
        img: "https://i.postimg.cc/KjTYyHDM/10.jpg"
    },
    {
        id: 11,
        img: "https://i.postimg.cc/52g21vLn/11.jpg"
    },
    {
        id: 12,
        img: "https://i.postimg.cc/ZYvn3Wz5/12.jpg"
    },
    {
        id: 13,
        img: "https://i.postimg.cc/8CnkfSyv/13.jpg"
    },
    {
        id: 14,
        img: "https://i.postimg.cc/FsjKWwRt/14.jpg"
    },
    {
        id: 15,
        img: "https://i.postimg.cc/RFkMGTxV/15.jpg"
    },
    {
        id: 16,
        img: "https://i.postimg.cc/hjzD95w5/16.jpg"
    },
    {
        id: 17,
        img: "https://i.postimg.cc/6qCBPGBV/17.jpg"
    },
    {
        id: 18,
        img: "https://i.postimg.cc/tRwz9Cn6/Microsoft-Teams-image-Rp.png"
    },
    {
        id: 19,
        img: "https://i.postimg.cc/4NZGdyJM/18.jpg"
    },
    {
        id: 20,
        img: "https://i.postimg.cc/G3vrdG1G/20.jpg"
    },
]