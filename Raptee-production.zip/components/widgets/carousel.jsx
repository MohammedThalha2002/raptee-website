// https://i.postimg.cc/HsmPwfQq/1.jpg
// https://i.postimg.cc/qRRpvN7G/2.jpg
// https://i.postimg.cc/FFC7345R/3.jpg
// https://i.postimg.cc/TYWYb5J7/4.jpg
// https://i.postimg.cc/jqBnBb81/5.jpg
// https://i.postimg.cc/1zy9bCh2/6.jpg
// https://i.postimg.cc/HnrWBrDL/7.jpg
// https://i.postimg.cc/GtmTr300/8.jpg
// https://i.postimg.cc/Mp76Pk41/9.jpg
// https://i.postimg.cc/V5ywg4W7/10.jpg
// https://i.postimg.cc/FKP7p5dD/11.jpg
// https://i.postimg.cc/VkWSSbYy/12.jpg
// https://i.postimg.cc/LXnh0CjR/13.jpg
// https://i.postimg.cc/q7BN2MRN/14.jpg
// https://i.postimg.cc/LXwhdtVP/15.jpg
// https://i.postimg.cc/vHRD3vTF/16.jpg
// https://i.postimg.cc/664yrP9f/17.jpg
// https://i.postimg.cc/7YghcTJC/18.jpg
// https://i.postimg.cc/2Sryf8n0/19.jpg


export const caurosel = [
    {
        id: 1,
        img: "https://i.postimg.cc/HsmPwfQq/1.jpg"
    },
    {
        id: 2,
        img: "https://i.postimg.cc/qRRpvN7G/2.jpg"
    },
    {
        id: 3,
        img: "https://i.postimg.cc/FFC7345R/3.jpg"
    },
    {
        id: 4,
        img: "https://i.postimg.cc/TYWYb5J7/4.jpg"
    },
    {
        id: 5,
        img: "https://i.postimg.cc/jqBnBb81/5.jpg"
    },
    {
        id: 6,
        img: "https://i.postimg.cc/1zy9bCh2/6.jpg"
    },
    {
        id: 7,
        img: "https://i.postimg.cc/HnrWBrDL/7.jpg"
    },
    {
        id: 8,
        img: "https://i.postimg.cc/GtmTr300/8.jpg"
    },
    {
        id: 9,
        img: "https://i.postimg.cc/Mp76Pk41/9.jpg"
    },
    {
        id: 10,
        img: "https://i.postimg.cc/V5ywg4W7/10.jpg"
    },
    {
        id: 11,
        img: "https://i.postimg.cc/FKP7p5dD/11.jpg"
    },
    {
        id: 12,
        img: "https://i.postimg.cc/VkWSSbYy/12.jpg"
    },
    {
        id: 13,
        img: "https://i.postimg.cc/LXnh0CjR/13.jpg"
    },
    {
        id: 14,
        img: "https://i.postimg.cc/q7BN2MRN/14.jpg"
    },
    {
        id: 15,
        img: "https://i.postimg.cc/LXwhdtVP/15.jpg"
    },
    {
        id: 16,
        img: "https://i.postimg.cc/vHRD3vTF/16.jpg"
    },
    {
        id: 17,
        img: "https://i.postimg.cc/pT1tTbFy/17.jpg"
    },
    {
        id: 18,
        img: "https://i.postimg.cc/7YghcTJC/18.jpg"
    },
    {
        id: 19,
        img: "https://i.postimg.cc/2Sryf8n0/19.jpg"
    },
]