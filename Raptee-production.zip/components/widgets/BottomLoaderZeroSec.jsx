import React from 'react'

function BottomLoaderZeroSec() {
    return (
        <div className="absolute bottom-10 left-60 -translate-x-1/2">
            <div className="loader-line"></div>
        </div>
    )
}

export default BottomLoaderZeroSec